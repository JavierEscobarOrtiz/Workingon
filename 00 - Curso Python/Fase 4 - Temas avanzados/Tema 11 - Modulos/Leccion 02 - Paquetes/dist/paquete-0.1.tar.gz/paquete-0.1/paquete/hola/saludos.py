#Este es un modulo con funciones que saludan
def saludar():
	print("Te estoy saludando desde el modulo saludar")

class Saludo():
	def __init__(self):
		print("Hola te estoy saludando desde el init de la case saludo")