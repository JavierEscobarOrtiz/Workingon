#Este es un modulo con funciones que saludan
def despedirse():
	print("Adios, me estoy despidiendo desde la funcion despedirse del modulo despedidas")

class Despedida():
	def __init__(self):
		print("Adios, te estoy despidiendo desde el init de la clase Despedida")